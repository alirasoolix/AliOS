const CACHE="alios-shell-v1.0.0-beta.1";
const SHELL=["/","/index.html","/app.css","/modules.js","/app.js","/manifest.webmanifest","/icon-192.png","/icon-512.png"];

self.addEventListener("install",event=>{
  event.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting()));
});
self.addEventListener("activate",event=>{
  event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));
});
self.addEventListener("fetch",event=>{
  const req=event.request,url=new URL(req.url);
  if(url.origin===self.location.origin && url.pathname.startsWith("/api/")) return;
  if(req.mode==="navigate"){
    event.respondWith(fetch(req).then(r=>{const clone=r.clone();caches.open(CACHE).then(c=>c.put("/index.html",clone));return r}).catch(()=>caches.match("/index.html")));
    return;
  }
  if(url.origin===self.location.origin){
    event.respondWith(caches.match(req).then(hit=>hit||fetch(req).then(r=>{if(r.ok)caches.open(CACHE).then(c=>c.put(req,r.clone()));return r})));
    return;
  }
  if(url.hostname.includes("fonts.googleapis.com")||url.hostname.includes("fonts.gstatic.com")){
    event.respondWith(caches.match(req).then(hit=>hit||fetch(req).then(r=>{if(r.ok)caches.open(CACHE).then(c=>c.put(req,r.clone()));return r}).catch(()=>hit)));
  }
});
