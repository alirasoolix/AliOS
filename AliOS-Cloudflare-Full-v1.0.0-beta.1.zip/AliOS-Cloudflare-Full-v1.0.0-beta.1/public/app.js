const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const API_HEADERS = { "content-type": "application/json", "x-alios-action": "1" };
const DB_NAME = "alios_full_local_v1";
const DB_VERSION = 1;
const PBKDF2_ITERATIONS = 210000;

let idb;
let vaultKey = null;
let records = [];
let modules = { ...window.ALIO_MODULES };
let currentView = "today";
let currentCardMode = "cards";
let editingRecordId = null;
let aiConfigured = false;
let lastActivity = Date.now();
let autoLockMinutes = Number(localStorage.getItem("alios_auto_lock") || 15);
const deviceId = localStorage.getItem("alios_device_id") || crypto.randomUUID();
localStorage.setItem("alios_device_id", deviceId);

const categories = [
  ["core","اصلی"],["planning","برنامه‌ریزی"],["brain","ذهن و دانش"],["finance","مالی و دارایی"],
  ["health","سلامت و فیتنس"],["growth","رشد و یادگیری"],["life","زندگی"],["work","کار"],["system","سیستم"]
];

document.addEventListener("DOMContentLoaded", init);

async function init() {
  idb = await openIDB();
  applyLocalUi();
  setClock(); setInterval(setClock, 30000);
  setNetwork();
  wireUI();
  registerSW();
  trackActivity();
  setInterval(checkAutoLock, 30000);

  if (navigator.onLine) {
    try {
      const boot = await fetchJSON("/api/bootstrap");
      aiConfigured = Boolean(boot.aiConfigured);
      $("#aiSettingStatus").textContent = aiConfigured ? "فعال" : "تنظیم نشده";
      setupAuthMode(boot.configured ? "login" : "setup");
    } catch {
      setupAuthMode((await vaultExists()) ? "offline" : "login");
    }
  } else {
    setupAuthMode((await vaultExists()) ? "offline" : "offline-empty");
  }
}

function wireUI() {
  $("#authForm").addEventListener("submit", handleAuth);
  $("#aiSend").addEventListener("click", sendAI);
  $("#aiInput").addEventListener("keydown", e => { if (e.key === "Enter") sendAI(); });
  $$("[data-ai]").forEach(b => b.addEventListener("click", () => { $("#aiInput").value=b.dataset.ai; $("#aiInput").focus(); }));
  $$("[data-open-module]").forEach(b => b.addEventListener("click",()=>switchView(b.dataset.openModule)));
  $("#moduleAdd").addEventListener("click",()=>openRecordDialog(currentView));
  $("#moduleSearch").addEventListener("input",()=>renderModule(currentView));
  $("#viewCards").addEventListener("click",()=>{currentCardMode="cards";$("#viewCards").classList.add("active");$("#viewTable").classList.remove("active");renderModule(currentView)});
  $("#viewTable").addEventListener("click",()=>{currentCardMode="table";$("#viewTable").classList.add("active");$("#viewCards").classList.remove("active");renderModule(currentView)});
  $("#recordForm").addEventListener("submit", saveRecordForm);
  $("#customModuleForm").addEventListener("submit", saveCustomModule);
  $("#newCustomModule").addEventListener("click",()=>$("#customModuleDialog").showModal());
  $("#passwordForm").addEventListener("submit", changePassword);
  $("#loadSessions").addEventListener("click", loadSessions);
  $("#exportBtn").addEventListener("click", exportBackup);
  $("#importInput").addEventListener("change", importBackup);
  $("#syncNowBtn").addEventListener("click",async()=>{await syncAll();await pullServer();renderAll();toast("همگام‌سازی انجام شد.")});
  $("#saveUiSettings").addEventListener("click", saveUiSettings);
  $("#sideSearchBtn").addEventListener("click",()=>{const q=$("#sideSearch").value.trim();switchView("search");$("#globalSearch").value=q;performSearch(q)});
  $("#sideSearch").addEventListener("keydown",e=>{if(e.key==="Enter")$("#sideSearchBtn").click()});
  $("#globalSearchBtn").addEventListener("click",()=>performSearch($("#globalSearch").value.trim()));
  $("#globalSearch").addEventListener("keydown",e=>{if(e.key==="Enter")performSearch($("#globalSearch").value.trim())});
  $("#commandBtn").addEventListener("click",openCommand);
  $("#commandInput").addEventListener("input",renderCommandResults);
  $("#commandInput").addEventListener("keydown",e=>{if(e.key==="Escape")$("#commandDialog").close()});
  addEventListener("keydown",e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="k"){e.preventDefault();openCommand()}});
  $("#mobilePlus").addEventListener("click",()=>openRecordDialog("tasks"));
  $$("[data-mobile-view]").forEach(b=>b.addEventListener("click",()=>{
    const v=b.dataset.mobileView;
    if(v==="ai"){switchView("today");setTimeout(()=>$("#aiInput").focus(),50)} else switchView(v);
  }));
  addEventListener("online",async()=>{setNetwork();if(vaultKey){await syncAll();await pullServer();renderAll()}});
  addEventListener("offline",setNetwork);
}

function trackActivity(){
  ["pointerdown","keydown","touchstart"].forEach(ev=>addEventListener(ev,()=>lastActivity=Date.now(),{passive:true}));
}
function checkAutoLock(){
  if(!vaultKey||autoLockMinutes<=0)return;
  if(Date.now()-lastActivity>autoLockMinutes*60000)lockApp();
}
function lockApp(){
  vaultKey=null;
  records=[];
  $("#app").classList.add("hidden");
  setupAuthMode(navigator.onLine?"login":"offline");
  toast("AliOS قفل شد.");
}

async function registerSW(){
  if("serviceWorker" in navigator){try{await navigator.serviceWorker.register("/sw.js")}catch{}}
}

function setupAuthMode(mode){
  $("#authScreen").classList.remove("hidden"); $("#app").classList.add("hidden");
  const input=$("#passwordInput"),btn=$("#authSubmit");
  input.value="";input.disabled=false;btn.disabled=false;
  if(mode==="setup"){
    $("#authTitle").textContent="راه‌اندازی AliOS";
    $("#authHint").textContent="یک رمز شخصی قوی بساز؛ داده آفلاین همین دستگاه هم با آن رمزگذاری می‌شود.";
    btn.textContent="ساخت AliOS";input.autocomplete="new-password";
  }else if(mode==="offline"){
    $("#authTitle").textContent="ورود آفلاین";
    $("#authHint").textContent="اینترنت قطع است؛ Vault رمزگذاری‌شده محلی را باز کن.";
    btn.textContent="باز کردن آفلاین";
  }else if(mode==="offline-empty"){
    $("#authTitle").textContent="برای اولین راه‌اندازی اینترنت لازم است";
    $("#authHint").textContent="بعد از اولین ورود، هسته AliOS آفلاین هم باز می‌شود.";
    input.disabled=true;btn.disabled=true;
  }else{
    $("#authTitle").textContent="ورود به AliOS";$("#authHint").textContent="رمز شخصی خودت را وارد کن.";btn.textContent="ورود";
  }
  input.dataset.mode=mode;
}

async function handleAuth(e){
  e.preventDefault();
  const password=$("#passwordInput").value,mode=$("#passwordInput").dataset.mode;
  try{
    if(mode==="setup"){
      await fetchJSON("/api/setup",{method:"POST",headers:API_HEADERS,body:JSON.stringify({password})});
      await createVault(password,true);
    }else if(mode==="offline"){
      await unlockVault(password);
    }else{
      await fetchJSON("/api/auth/login",{method:"POST",headers:API_HEADERS,body:JSON.stringify({password})});
      if(await vaultExists()) await unlockVault(password); else await createVault(password,false);
    }
    lastActivity=Date.now();showApp();await loadLocal();await loadCustomModules();
    if(navigator.onLine){await loadServerSettings();await syncAll();await pullServer();}
    renderNav();renderQuickGrid();renderAll();
  }catch(err){toast(errorMessage(err))}
}

function showApp(){
  $("#authScreen").classList.add("hidden");$("#app").classList.remove("hidden");
  setNetwork();
}


function renderQuickGrid(){
  const picks=["tasks","finance","notes","workouts","goals","nutrition","habits","vehicle"];
  $("#quickGrid").innerHTML=picks.map(slug=>{
    const m=modules[slug];return `<button data-qm="${slug}"><b>${esc(m?.icon||"＋")}</b><span>${esc(m?.label||slug)}</span></button>`;
  }).join("");
  $("#quickGrid").querySelectorAll("[data-qm]").forEach(b=>b.addEventListener("click",()=>openRecordDialog(b.dataset.qm)));
}

function renderNav(){
  const nav=$("#sideNav");nav.innerHTML="";
  for(const [cat,label] of categories){
    const entries=Object.entries(modules).filter(([slug,m])=>m.category===cat && !["ai"].includes(slug));
    if(!entries.length)continue;
    const title=document.createElement("div");title.className="nav-group-title";title.textContent=label;nav.append(title);
    for(const [slug,m] of entries){
      const b=document.createElement("button");b.className="nav"+(currentView===slug?" active":"");
      b.dataset.view=slug;b.innerHTML=`<span class="ico">${esc(m.icon||"•")}</span><span>${esc(m.label)}</span>`;
      b.addEventListener("click",()=>switchView(slug));nav.append(b);
    }
  }
}

function switchView(view){
  currentView=view;renderNav();
  $$(".view").forEach(v=>v.classList.remove("active"));
  const meta=modules[view];
  if(view==="today"){
    $("#todayView").classList.add("active");setPage("امروز","مرکز فرماندهی زندگی شخصی تو");renderHome();
  }else if(view==="analytics"){
    $("#analyticsView").classList.add("active");setPage("تحلیل‌ها","نگاه کلان به داده‌های زندگی");renderAnalytics();
  }else if(view==="search"){
    $("#searchView").classList.add("active");setPage("جست‌وجوی سراسری","همه‌چیز را یکجا پیدا کن");setTimeout(()=>$("#globalSearch").focus(),50);
  }else if(view==="custom_modules"){
    $("#customModuleView").classList.add("active");setPage("ماژول‌ساز","AliOS را با زندگی خودت گسترش بده");renderCustomModules();
  }else if(view==="trash"){
    $("#trashView").classList.add("active");setPage("سطل زباله","رکوردهای حذف‌شده قابل بازیابی هستند");renderTrash();
  }else if(view==="settings"){
    $("#settingsView").classList.add("active");setPage("تنظیمات","امنیت، ظاهر، Backup و Sync");
  }else{
    $("#moduleView").classList.add("active");setPage(meta?.label||view,meta?.description||"");
    $("#moduleSearch").value="";renderModule(view);
  }
}
function setPage(t,s){$("#pageTitle").textContent=t;$("#pageSubtitle").textContent=s}

async function pullServer(){
  if(!navigator.onLine)return;
  try{
    const data=await fetchJSON("/api/records?include_deleted=1");
    for(const rec of data.records||[])await putEncrypted("records",rec.id,rec);
    await loadLocal();await loadCustomModules();renderNav();
  }catch(e){if(e.status===401)toast("Session سرور منقضی شده؛ اطلاعات محلی همچنان محفوظ است.")}
}

async function syncAll(){
  if(!navigator.onLine||!vaultKey)return;
  const ops=await readEncryptedStore("outbox");
  if(!ops.length){updateSyncText();return}
  $("#syncText").textContent=`${fa(ops.length)} تغییر در حال Sync…`;
  try{
    const data=await fetchJSON("/api/sync",{method:"POST",headers:API_HEADERS,body:JSON.stringify({ops})});
    for(const a of data.applied||[]){if(a.record)await putEncrypted("records",a.record.id,a.record);if(a.op_id)await deleteStoreItem("outbox",a.op_id)}
    if((data.conflicts||[]).length){
      await idbPut("meta","conflicts",data.conflicts);toast(`${fa(data.conflicts.length)} تعارض Sync ثبت شد.`);
    }
    await loadLocal();
  }catch{}
  updateSyncText();
}

async function saveLocalRecord(rec,baseVersion=0){
  rec.updated_at=new Date().toISOString();
  await putEncrypted("records",rec.id,rec);
  const op={op_id:crypto.randomUUID(),kind:"upsert",base_version:baseVersion,record:rec};
  await putEncrypted("outbox",op.op_id,op);
  await loadLocal();renderAll();if(navigator.onLine)await syncAll();
}

async function deleteRecordLocal(id){
  const rec=records.find(r=>r.id===id);if(!rec)return;
  const base=Number(rec.version||0);rec.deleted_at=new Date().toISOString();rec.updated_at=rec.deleted_at;
  await putEncrypted("records",id,rec);
  const op={op_id:crypto.randomUUID(),kind:"delete",base_version:base,id};
  await putEncrypted("outbox",op.op_id,op);
  await loadLocal();renderAll();if(navigator.onLine)await syncAll();
}
async function restoreRecordLocal(id){
  const rec=records.find(r=>r.id===id);if(!rec)return;
  const base=Number(rec.version||0);rec.deleted_at=null;rec.updated_at=new Date().toISOString();
  await putEncrypted("records",id,rec);
  const op={op_id:crypto.randomUUID(),kind:"restore",base_version:base,id,record:rec};
  await putEncrypted("outbox",op.op_id,op);
  await loadLocal();renderAll();if(navigator.onLine)await syncAll();
}

function openRecordDialog(moduleSlug,recordId=null){
  const m=modules[moduleSlug];if(!m)return;
  editingRecordId=recordId;
  const rec=recordId?records.find(r=>r.id===recordId):null;
  $("#recordForm").dataset.module=moduleSlug;$("#recordDialogTitle").textContent=(rec?"ویرایش ":"افزودن ")+m.label;
  $("#recordDialogHint").textContent=m.description||"";
  $("#recordTitle").value=rec?.title||"";
  $("#recordOccurred").value=toLocalDateTime(rec?.occurred_at||new Date().toISOString());
  const box=$("#dynamicFields");box.innerHTML="";
  for(const f of m.fields||[]){
    const label=document.createElement("label");
    if(["textarea"].includes(f.type))label.classList.add("wide");
    label.textContent=f.label;
    const input=makeFieldInput(f,rec?.payload?.[f.key]);
    input.dataset.key=f.key;input.dataset.type=f.type;label.append(input);box.append(label);
  }
  $("#recordDialog").showModal();setTimeout(()=>$("#recordTitle").focus(),50);
}

function makeFieldInput(f,value){
  let el;
  if(f.type==="textarea"){el=document.createElement("textarea");el.value=value??""}
  else if(f.type==="select"){el=document.createElement("select");for(const o of f.options||[]){const op=document.createElement("option");op.value=o;op.textContent=o;if(String(value??"")===String(o))op.selected=true;el.append(op)}}
  else if(f.type==="boolean"){el=document.createElement("select");for(const [v,t] of [["false","خیر"],["true","بله"]]){const op=document.createElement("option");op.value=v;op.textContent=t;if(Boolean(value)===(v==="true"))op.selected=true;el.append(op)}}
  else{el=document.createElement("input");el.type=fieldHtmlType(f.type);el.value=formatInputValue(f.type,value)}
  el.placeholder=f.label;return el;
}
function fieldHtmlType(t){return ({number:"number",currency:"number",date:"date",datetime:"datetime-local",url:"url"}[t]||"text")}
function formatInputValue(t,v){if(v==null)return"";if(t==="datetime")return toLocalDateTime(v);if(t==="date")return String(v).slice(0,10);return v}
function parseFieldValue(el){
  const t=el.dataset.type,v=el.value;
  if(t==="number"||t==="currency")return v===""?0:Number(normalizeDigits(v));
  if(t==="boolean")return v==="true";
  if(t==="datetime")return v?new Date(v).toISOString():"";
  return v;
}

async function saveRecordForm(e){
  e.preventDefault();
  const moduleSlug=$("#recordForm").dataset.module,m=modules[moduleSlug];if(!m)return;
  const title=$("#recordTitle").value.trim();if(!title)return;
  const payload={};$("#dynamicFields").querySelectorAll("[data-key]").forEach(el=>payload[el.dataset.key]=parseFieldValue(el));
  const occurred=$("#recordOccurred").value?new Date($("#recordOccurred").value).toISOString():new Date().toISOString();
  const old=editingRecordId?records.find(r=>r.id===editingRecordId):null;
  const rec=old?{...old,title,payload,occurred_at:occurred,device_id:deviceId}:{id:crypto.randomUUID(),module:moduleSlug,title,payload,occurred_at:occurred,created_at:new Date().toISOString(),updated_at:new Date().toISOString(),deleted_at:null,version:1,device_id:deviceId};
  await saveLocalRecord(rec,old?Number(old.version||0):0);
  $("#recordDialog").close();toast(old?"ویرایش شد.":"ثبت شد.");editingRecordId=null;
}

function renderAll(){renderHome();if(currentView&&!["today","settings","analytics","search","custom_modules","trash"].includes(currentView))renderModule(currentView);if(currentView==="analytics")renderAnalytics();if(currentView==="trash")renderTrash();if(currentView==="custom_modules")renderCustomModules();updateSyncText()}

function renderHome(){
  const active=records.filter(r=>!r.deleted_at),todayKey=tehranDayKey(new Date());
  const isToday=r=>tehranDayKey(new Date(r.occurred_at||r.created_at))===todayKey;
  const tasks=active.filter(r=>r.module==="tasks"&&isToday(r)).slice(0,5);
  renderMiniList("#todayTasks",tasks,r=>`${esc(r.title)}<small>${esc(r.payload?.priority||r.payload?.status||"")}</small>`);

  const expenses=active.filter(r=>r.module==="finance"&&isToday(r)&&String(r.payload?.transaction_type||"expense")==="expense");
  const expTotal=expenses.reduce((s,r)=>s+Number(r.payload?.amount||0),0);$("#todayExpense").textContent=money(expTotal);
  renderMiniList("#recentExpenses",expenses.slice(0,4),r=>`${esc(r.title)}<small>${esc(r.payload?.category||"")}</small><b class="negative">−${money(r.payload?.amount||0)}</b>`);

  const workouts=active.filter(r=>r.module==="workouts"&&isToday(r)).slice(0,2);
  renderMiniList("#todayWorkout",workouts,r=>`${esc(r.title)}<small>${esc(r.payload?.focus||"")}</small>`);

  const meals=active.filter(r=>r.module==="nutrition"&&isToday(r));
  const cal=meals.reduce((s,r)=>s+Number(r.payload?.calories||0),0),pro=meals.reduce((s,r)=>s+Number(r.payload?.protein||0),0),carb=meals.reduce((s,r)=>s+Number(r.payload?.carbs||0),0),fat=meals.reduce((s,r)=>s+Number(r.payload?.fat||0),0);
  $("#nutritionWidget").innerHTML=[["کالری",fa(cal)],["پروتئین",fa(pro)+"g"],["کربوهیدرات",fa(carb)+"g"],["چربی",fa(fat)+"g"]].map(x=>`<div class="macro"><b>${x[1]}</b><span>${x[0]}</span></div>`).join("");

  const goals=active.filter(r=>r.module==="goals").slice(0,5);
  renderMiniList("#goalWidget",goals,r=>{const target=Number(r.payload?.target||0),cur=Number(r.payload?.current||0),p=target?Math.min(100,Math.round(cur/target*100)):0;return `${esc(r.title)}<small>${fa(p)}٪ پیشرفت</small><div class="progress"><i style="width:${p}%"></i></div>`});
  const habits=active.filter(r=>r.module==="habits").slice(0,5);renderMiniList("#habitWidget",habits,r=>`${esc(r.title)}<small>Streak: ${fa(r.payload?.streak||0)}</small>`);
  const inv=active.filter(r=>r.module==="investments").slice(0,5);renderMiniList("#investmentWidget",inv,r=>`${esc(r.title)}<small>${esc(r.payload?.asset_type||"دارایی")}</small><b>${money(Number(r.payload?.current_price||0)*Number(r.payload?.quantity||0))}</b>`);
  const notes=active.filter(r=>r.module==="notes").slice(0,5);renderMiniList("#noteWidget",notes,r=>`${esc(r.title)}<small>${esc(String(r.payload?.content||"").slice(0,70))}</small>`);

  const done=active.filter(r=>r.module==="tasks"&&isToday(r)&&r.payload?.status==="done").length,total=active.filter(r=>r.module==="tasks"&&isToday(r)).length;
  const progress=total?Math.round(done/total*100):10;$("#dayProgress").style.width=`${progress}%`;
  $("#todaySummary").textContent=`${fa(total)} کار • ${money(expTotal)} هزینه • ${fa(workouts.length)} تمرین`;
  const xp=active.length*7+done*10;$("#lifeLevel").textContent=`Level ${Math.max(1,Math.floor(xp/250)+1)}`;
}

function renderMiniList(selector,items,formatter){
  const el=$(selector);if(!items.length){el.classList.add("empty");return}
  el.classList.remove("empty");el.innerHTML=items.map(r=>`<div class="row"><span>${formatter(r)}</span></div>`).join("");
}

function renderModule(slug){
  const m=modules[slug];if(!m)return;
  let list=records.filter(r=>!r.deleted_at&&r.module===slug);
  const q=normalizeText($("#moduleSearch").value||"");if(q)list=list.filter(r=>normalizeText(r.title+" "+JSON.stringify(r.payload)).includes(q));
  const now=Date.now();const last7=list.filter(r=>now-new Date(r.updated_at||r.created_at).getTime()<7*86400000).length;
  $("#moduleStats").innerHTML=[
    statHtml("کل",list.length),statHtml("۷ روز اخیر",last7),statHtml("امروز",list.filter(r=>tehranDayKey(new Date(r.occurred_at||r.created_at))===tehranDayKey(new Date())).length),statHtml("فیلدها",(m.fields||[]).length)
  ].join("");
  if(currentCardMode==="cards"){renderModuleCards(list,m);$("#moduleRecords").classList.remove("hidden");$("#moduleTableWrap").classList.add("hidden")}
  else{renderModuleTable(list,m);$("#moduleRecords").classList.add("hidden");$("#moduleTableWrap").classList.remove("hidden")}
}

function renderModuleCards(list,m){
  const box=$("#moduleRecords");if(!list.length){box.innerHTML=`<article class="card"><h3>هنوز چیزی ثبت نشده</h3><p>از «افزودن» یا Ali AI استفاده کن.</p></article>`;return}
  box.innerHTML=list.map(r=>`<article class="record-card">
    <div class="record-actions"><button data-edit="${r.id}">✎</button><button data-del="${r.id}">⌫</button></div>
    <h3>${esc(r.title)}</h3><p>${esc(recordSummary(r,m))}</p><small>${formatPersianDate(r.occurred_at||r.created_at)}</small>
  </article>`).join("");
  box.querySelectorAll("[data-edit]").forEach(b=>b.addEventListener("click",()=>openRecordDialog(currentView,b.dataset.edit)));
  box.querySelectorAll("[data-del]").forEach(b=>b.addEventListener("click",()=>{if(confirm("به سطل زباله منتقل شود؟"))deleteRecordLocal(b.dataset.del)}));
}

function renderModuleTable(list,m){
  const fields=(m.fields||[]).slice(0,5);
  $("#moduleTableHead").innerHTML=`<tr><th>عنوان</th>${fields.map(f=>`<th>${esc(f.label)}</th>`).join("")}<th>تاریخ</th></tr>`;
  $("#moduleTableBody").innerHTML=list.map(r=>`<tr data-row="${r.id}"><td>${esc(r.title)}</td>${fields.map(f=>`<td>${esc(formatField(r.payload?.[f.key],f.type))}</td>`).join("")}<td>${formatPersianDate(r.occurred_at||r.created_at)}</td></tr>`).join("");
  $("#moduleTableBody").querySelectorAll("tr").forEach(tr=>tr.addEventListener("dblclick",()=>openRecordDialog(currentView,tr.dataset.row)));
}

function recordSummary(r,m){
  const parts=[];for(const f of (m.fields||[])){const v=r.payload?.[f.key];if(v!==undefined&&v!==""&&v!==false&&parts.length<4)parts.push(`${f.label}: ${formatField(v,f.type)}`)}
  return parts.join(" • ")||"بدون جزئیات";
}
function formatField(v,t){if(v==null)return"";if(t==="currency")return money(v);if(t==="boolean")return v?"بله":"خیر";if(t==="date"||t==="datetime")return formatPersianDate(v);return String(v)}

function renderAnalytics(){
  const active=records.filter(r=>!r.deleted_at);
  const modulesUsed=[...new Set(active.map(r=>r.module))].length;
  const totalExpense=active.filter(r=>r.module==="finance"&&r.payload?.transaction_type==="expense").reduce((s,r)=>s+Number(r.payload?.amount||0),0);
  const totalIncome=active.filter(r=>r.module==="finance"&&r.payload?.transaction_type==="income").reduce((s,r)=>s+Number(r.payload?.amount||0),0);
  $("#analyticsStats").innerHTML=[statHtml("رکوردها",active.length),statHtml("ماژول فعال",modulesUsed),statHtml("کل درآمد",money(totalIncome)),statHtml("کل هزینه",money(totalExpense))].join("");
  const counts={};active.forEach(r=>counts[r.module]=(counts[r.module]||0)+1);const max=Math.max(1,...Object.values(counts));
  $("#moduleBars").innerHTML=Object.entries(counts).sort((a,b)=>b[1]-a[1]).slice(0,12).map(([slug,n])=>`<div class="bar-row"><span>${esc(modules[slug]?.label||slug)}</span><div class="bar"><i style="width:${n/max*100}%"></i></div><b>${fa(n)}</b></div>`).join("")||"داده‌ای نیست.";
  $("#financeAnalytics").innerHTML=`<div class="system-row"><span>درآمد</span><b class="positive">${money(totalIncome)}</b></div><div class="system-row"><span>هزینه</span><b class="negative">${money(totalExpense)}</b></div><div class="system-row"><span>خالص</span><b>${money(totalIncome-totalExpense)}</b></div>`;
  const goals=active.filter(r=>r.module==="goals");$("#goalAnalytics").innerHTML=goals.slice(0,8).map(r=>{const t=Number(r.payload?.target||0),c=Number(r.payload?.current||0),p=t?Math.min(100,Math.round(c/t*100)):0;return `<div><div class="system-row"><span>${esc(r.title)}</span><b>${fa(p)}٪</b></div><div class="progress"><i style="width:${p}%"></i></div></div>`}).join("")||"هدفی ثبت نشده.";
  $("#activityAnalytics").innerHTML=active.slice(0,10).map(r=>`<div class="system-row"><span>${esc(r.title)}</span><b>${esc(modules[r.module]?.label||r.module)}</b></div>`).join("")||"فعالیتی نیست.";
}

function performSearch(q){
  const nq=normalizeText(q);let list=records.filter(r=>!r.deleted_at);
  if(nq)list=list.filter(r=>normalizeText(r.title+" "+JSON.stringify(r.payload)+" "+(modules[r.module]?.label||r.module)).includes(nq));
  $("#searchResults").innerHTML=list.slice(0,100).map(r=>`<article class="record-card"><h3>${esc(r.title)}</h3><p>${esc(modules[r.module]?.label||r.module)} • ${esc(recordSummary(r,modules[r.module]||{fields:[]}))}</p><small>${formatPersianDate(r.occurred_at||r.created_at)}</small></article>`).join("")||`<article class="card"><p>نتیجه‌ای پیدا نشد.</p></article>`;
}

async function saveCustomModule(e){
  e.preventDefault();
  const label=$("#cmLabel").value.trim(),slug=$("#cmSlug").value.trim().toLowerCase(),icon=$("#cmIcon").value.trim()||"✦";
  if(!/^[a-z][a-z0-9_-]*$/.test(slug))return toast("شناسه ماژول معتبر نیست.");
  if(modules[slug])return toast("این شناسه قبلاً وجود دارد.");
  const fields=$("#cmFields").value.split("\n").map(x=>x.trim()).filter(Boolean).map((line,i)=>{
    const [name,typeRaw]=line.split("|").map(x=>x.trim());const type=["text","number","currency","date","datetime","textarea","boolean","url"].includes(typeRaw)?typeRaw:"text";
    return {key:`field_${i+1}`,label:name||`فیلد ${i+1}`,type};
  });
  const payload={slug,label,icon,fields,category:"life",description:`ماژول سفارشی ${label}`};
  const rec={id:crypto.randomUUID(),module:"custom_modules",title:label,payload,occurred_at:new Date().toISOString(),created_at:new Date().toISOString(),updated_at:new Date().toISOString(),deleted_at:null,version:1,device_id:deviceId};
  await saveLocalRecord(rec,0);$("#customModuleDialog").close();await loadCustomModules();renderNav();renderCustomModules();toast("ماژول جدید ساخته شد.");
}
async function loadCustomModules(){
  modules={...window.ALIO_MODULES};
  for(const r of records.filter(x=>!x.deleted_at&&x.module==="custom_modules")){
    const p=r.payload||{};if(p.slug&&p.label)modules[p.slug]={label:p.label,icon:p.icon||"✦",category:p.category||"life",description:p.description||"",fields:Array.isArray(p.fields)?p.fields:[]}
  }
}
function renderCustomModules(){
  const list=records.filter(r=>!r.deleted_at&&r.module==="custom_modules");
  $("#customModuleList").innerHTML=list.map(r=>`<article class="record-card"><h3>${esc(r.payload?.icon||"✦")} ${esc(r.payload?.label||r.title)}</h3><p>شناسه: ${esc(r.payload?.slug||"")} • ${fa((r.payload?.fields||[]).length)} فیلد</p></article>`).join("")||`<article class="card"><h3>ماژول سفارشی نداری</h3><p>هر بخش خاص زندگی‌ات را می‌توانی بسازی.</p></article>`;
}

function renderTrash(){
  const list=records.filter(r=>r.deleted_at);
  $("#trashList").innerHTML=list.map(r=>`<article class="record-card"><h3>${esc(r.title)}</h3><p>${esc(modules[r.module]?.label||r.module)}</p><small>حذف: ${formatPersianDate(r.deleted_at)}</small><div style="margin-top:10px"><button class="primary" data-restore="${r.id}">بازیابی</button></div></article>`).join("")||`<article class="card"><p>سطل زباله خالی است.</p></article>`;
  $("#trashList").querySelectorAll("[data-restore]").forEach(b=>b.addEventListener("click",()=>restoreRecordLocal(b.dataset.restore)));
}

async function sendAI(){
  const input=$("#aiInput"),message=input.value.trim();if(!message)return;
  if(!navigator.onLine){toast("AI به اینترنت نیاز دارد؛ بقیه AliOS آفلاین قابل استفاده است.");return}
  if(!aiConfigured){toast("OPENAI_API_KEY هنوز روی Worker تنظیم نشده.");return}
  $("#aiSend").disabled=true;$("#aiReply").classList.remove("hidden");$("#aiReply").textContent="در حال تحلیل و اعمال…";
  try{
    const data=await fetchJSON("/api/ai",{method:"POST",headers:API_HEADERS,body:JSON.stringify({message})});
    $("#aiReply").textContent=data.needs_clarification?(data.clarifying_question||data.reply):(data.reply||"انجام شد.");
    for(const rec of data.records||[])await putEncrypted("records",rec.id,rec);
    if((data.pending_actions||[]).length)$("#aiReply").textContent+="\nبعضی تغییرات حساس نیاز به تأیید دارند.";
    await loadLocal();renderAll();input.value="";
  }catch(e){$("#aiReply").textContent=errorMessage(e)}
  finally{$("#aiSend").disabled=false}
}

async function changePassword(e){
  e.preventDefault();if(!navigator.onLine)return toast("تغییر رمز نیاز به اینترنت دارد.");
  const oldPass=$("#currentPassword").value,newPass=$("#newPassword").value;
  try{
    // decrypt all before server invalidates session
    await unlockVault(oldPass);const localRecords=await readEncryptedStore("records"),outbox=await readEncryptedStore("outbox");
    await fetchJSON("/api/auth/change-password",{method:"POST",headers:API_HEADERS,body:JSON.stringify({currentPassword:oldPass,newPassword:newPass})});
    await createVault(newPass,true);
    for(const r of localRecords)await putEncrypted("records",r.id,r);
    for(const o of outbox)await putEncrypted("outbox",o.op_id||crypto.randomUUID(),o);
    $("#passwordForm").reset();toast("رمز تغییر کرد؛ Sessionهای قبلی بسته شدند.");
  }catch(e){toast(errorMessage(e))}
}

async function loadSessions(){
  if(!navigator.onLine)return toast("برای دیدن Sessionها اینترنت لازم است.");
  try{
    const data=await fetchJSON("/api/auth/sessions");$("#sessionList").innerHTML=(data.sessions||[]).map(s=>`<div class="row"><span>${esc((s.user_agent||"دستگاه").slice(0,70))}<small>${formatPersianDate(s.last_seen_at)}</small></span><button class="ghost" data-session="${s.id}">خروج</button></div>`).join("")||"Session فعالی نیست.";
    $("#sessionList").querySelectorAll("[data-session]").forEach(b=>b.addEventListener("click",async()=>{await fetchJSON(`/api/auth/sessions/${b.dataset.session}`,{method:"DELETE",headers:API_HEADERS});loadSessions()}));
  }catch(e){toast(errorMessage(e))}
}

function saveUiSettings(){
  const theme=$("#themeSelect").value,accent=$("#accentInput").value,lock=Number($("#autoLockSelect").value);
  localStorage.setItem("alios_theme",theme);localStorage.setItem("alios_accent",accent);localStorage.setItem("alios_auto_lock",lock);autoLockMinutes=lock;applyLocalUi();
  if(navigator.onLine)fetchJSON("/api/settings",{method:"PUT",headers:API_HEADERS,body:JSON.stringify({settings:{ui:{theme,accent},security:{autoLockMinutes:lock}}})}).catch(()=>{});
  toast("تنظیمات ذخیره شد.");
}
function applyLocalUi(){
  const theme=localStorage.getItem("alios_theme")||"dark",accent=localStorage.getItem("alios_accent")||"#6d7cff";
  document.documentElement.dataset.theme=theme;document.documentElement.style.setProperty("--accent",accent);
  if($("#themeSelect"))$("#themeSelect").value=theme;if($("#accentInput"))$("#accentInput").value=accent;if($("#autoLockSelect"))$("#autoLockSelect").value=String(autoLockMinutes);
}
async function loadServerSettings(){
  try{
    const data=await fetchJSON("/api/settings");const ui=data.settings?.ui,sec=data.settings?.security;
    if(ui?.theme&&!localStorage.getItem("alios_theme"))localStorage.setItem("alios_theme",ui.theme);
    if(ui?.accent&&!localStorage.getItem("alios_accent"))localStorage.setItem("alios_accent",ui.accent);
    if(sec?.autoLockMinutes&&!localStorage.getItem("alios_auto_lock")){localStorage.setItem("alios_auto_lock",sec.autoLockMinutes);autoLockMinutes=Number(sec.autoLockMinutes)}
    applyLocalUi();
  }catch{}
}

async function exportBackup(){
  const local=records;const custom=localStorage;
  const backup={app:"AliOS",version:"1.0.0-beta.1",exported_at:new Date().toISOString(),records:local,ui:{theme:localStorage.getItem("alios_theme"),accent:localStorage.getItem("alios_accent"),autoLock:autoLockMinutes}};
  const blob=new Blob([JSON.stringify(backup,null,2)],{type:"application/json"}),url=URL.createObjectURL(blob),a=document.createElement("a");
  a.href=url;a.download=`AliOS-backup-${new Date().toISOString().slice(0,10)}.json`;a.click();URL.revokeObjectURL(url);
}
async function importBackup(e){
  const file=e.target.files?.[0];if(!file)return;
  try{
    const data=JSON.parse(await file.text());if(!Array.isArray(data.records))throw new Error("invalid_backup");
    for(const r of data.records){if(r?.id&&r?.module)await putEncrypted("records",r.id,r)}
    await loadLocal();await loadCustomModules();renderNav();renderAll();toast(`${fa(data.records.length)} رکورد وارد شد.`);
  }catch{toast("فایل Backup معتبر نیست.")}finally{e.target.value=""}
}

function openCommand(){
  $("#commandDialog").showModal();$("#commandInput").value="";renderCommandResults();setTimeout(()=>$("#commandInput").focus(),30);
}
function renderCommandResults(){
  const q=normalizeText($("#commandInput").value||"");
  const list=Object.entries(modules).filter(([slug,m])=>!q||normalizeText(m.label+" "+slug).includes(q)).slice(0,15);
  $("#commandResults").innerHTML=list.map(([slug,m])=>`<div class="command-item" data-cmd="${slug}">${esc(m.icon||"•")} ${esc(m.label)}</div>`).join("");
  $("#commandResults").querySelectorAll("[data-cmd]").forEach(el=>el.addEventListener("click",()=>{$("#commandDialog").close();switchView(el.dataset.cmd)}));
}

function setClock(){
  const now=new Date();$("#tehranTime").textContent=new Intl.DateTimeFormat("fa-IR",{timeZone:"Asia/Tehran",hour:"2-digit",minute:"2-digit",hour12:false}).format(now);
  $("#jalaliDate").textContent=new Intl.DateTimeFormat("fa-IR-u-ca-persian",{timeZone:"Asia/Tehran",weekday:"short",day:"numeric",month:"long",year:"numeric"}).format(now);
}
function setNetwork(){
  const on=navigator.onLine;$("#authNetwork").textContent=on?"آنلاین":"آفلاین";
  if($("#statusText"))$("#statusText").textContent=on?"آنلاین":"آفلاین";if($("#statusDot"))$("#statusDot").style.background=on?"var(--accent2)":"var(--warn)";
  if($("#aiOnlineBadge")){$("#aiOnlineBadge").textContent=on?"آنلاین":"آفلاین";$("#aiOnlineBadge").style.color=on?"var(--accent2)":"var(--warn)"}
}
async function updateSyncText(){
  if(!vaultKey)return;const ops=await readEncryptedStore("outbox");
  $("#syncText").textContent=navigator.onLine?(ops.length?`${fa(ops.length)} تغییر در انتظار Sync`:"همه تغییرات همگام است"):`${fa(ops.length)} تغییر محلی • آفلاین`;
}

async function loadLocal(){records=(await readEncryptedStore("records")).sort((a,b)=>String(b.updated_at||"").localeCompare(String(a.updated_at||"")))}

// Secure local vault
function openIDB(){return new Promise((resolve,reject)=>{const req=indexedDB.open(DB_NAME,DB_VERSION);req.onupgradeneeded=()=>{const db=req.result;if(!db.objectStoreNames.contains("meta"))db.createObjectStore("meta");if(!db.objectStoreNames.contains("records"))db.createObjectStore("records");if(!db.objectStoreNames.contains("outbox"))db.createObjectStore("outbox")};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)})}
function txStore(name,mode="readonly"){return idb.transaction(name,mode).objectStore(name)}
function idbGet(store,key){return new Promise((res,rej)=>{const r=txStore(store).get(key);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
function idbPut(store,key,val){return new Promise((res,rej)=>{const r=txStore(store,"readwrite").put(val,key);r.onsuccess=()=>res();r.onerror=()=>rej(r.error)})}
function deleteStoreItem(store,key){return new Promise((res,rej)=>{const r=txStore(store,"readwrite").delete(key);r.onsuccess=()=>res();r.onerror=()=>rej(r.error)})}
function clearStore(store){return new Promise((res,rej)=>{const r=txStore(store,"readwrite").clear();r.onsuccess=()=>res();r.onerror=()=>rej(r.error)})}
function storeEntries(store){return new Promise((res,rej)=>{const out=[];const r=txStore(store).openCursor();r.onsuccess=()=>{const c=r.result;if(!c)return res(out);out.push([c.key,c.value]);c.continue()};r.onerror=()=>rej(r.error)})}
async function vaultExists(){return!!(await idbGet("meta","vault"))}
async function createVault(password,clearData){
  const salt=crypto.getRandomValues(new Uint8Array(16));vaultKey=await deriveKey(password,salt);const check=await encryptObject({ok:"AliOS-v1"});
  await idbPut("meta","vault",{salt:bytesToB64(salt),check});if(clearData){await clearStore("records");await clearStore("outbox")}
}
async function unlockVault(password){
  const meta=await idbGet("meta","vault");if(!meta)throw new Error("local_vault_missing");const key=await deriveKey(password,b64ToBytes(meta.salt)),old=vaultKey;vaultKey=key;
  try{const check=await decryptObject(meta.check);if(check.ok!=="AliOS-v1")throw new Error("wrong_password")}catch{vaultKey=old;throw new Error("wrong_password")}
}
async function deriveKey(password,salt){const base=await crypto.subtle.importKey("raw",new TextEncoder().encode(password),"PBKDF2",false,["deriveKey"]);return crypto.subtle.deriveKey({name:"PBKDF2",salt,iterations:PBKDF2_ITERATIONS,hash:"SHA-256"},base,{name:"AES-GCM",length:256},false,["encrypt","decrypt"])}
async function encryptObject(obj){if(!vaultKey)throw new Error("vault_locked");const iv=crypto.getRandomValues(new Uint8Array(12)),data=new TextEncoder().encode(JSON.stringify(obj)),cipher=await crypto.subtle.encrypt({name:"AES-GCM",iv},vaultKey,data);return{iv:bytesToB64(iv),data:bytesToB64(new Uint8Array(cipher))}}
async function decryptObject(env){if(!vaultKey)throw new Error("vault_locked");const plain=await crypto.subtle.decrypt({name:"AES-GCM",iv:b64ToBytes(env.iv)},vaultKey,b64ToBytes(env.data));return JSON.parse(new TextDecoder().decode(plain))}
async function putEncrypted(store,key,obj){await idbPut(store,key,await encryptObject(obj))}
async function readEncryptedStore(store){const entries=await storeEntries(store),out=[];for(const[,env]of entries){try{out.push(await decryptObject(env))}catch{}}return out}
function bytesToB64(bytes){let s="";bytes.forEach(b=>s+=String.fromCharCode(b));return btoa(s).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"")}
function b64ToBytes(s){s=s.replace(/-/g,"+").replace(/_/g,"/");while(s.length%4)s+="=";return Uint8Array.from(atob(s),c=>c.charCodeAt(0))}

async function fetchJSON(url,opts={}){
  const res=await fetch(url,{credentials:"same-origin",...opts});let data={};try{data=await res.json()}catch{}
  if(!res.ok){const e=new Error(data.error||`HTTP ${res.status}`);e.status=res.status;throw e}return data
}

// Formatting helpers
function statHtml(label,value){return`<div class="stat"><b>${typeof value==="number"?fa(value):value}</b><span>${label}</span></div>`}
function fa(x){return String(x).replace(/\d/g,d=>"۰۱۲۳۴۵۶۷۸۹"[d])}
function normalizeDigits(s=""){const m={"۰":"0","۱":"1","۲":"2","۳":"3","۴":"4","۵":"5","۶":"6","۷":"7","۸":"8","۹":"9"};return String(s).replace(/[۰-۹]/g,c=>m[c])}
function normalizeText(s=""){return normalizeDigits(String(s)).toLowerCase().replace(/ي/g,"ی").replace(/ك/g,"ک").trim()}
function money(n){return`${fa(Number(n||0).toLocaleString("en-US"))} تومان`}
function esc(s=""){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[m]))}
function formatPersianDate(s){try{return new Intl.DateTimeFormat("fa-IR-u-ca-persian",{timeZone:"Asia/Tehran",year:"numeric",month:"long",day:"numeric",hour:"2-digit",minute:"2-digit"}).format(new Date(s))}catch{return""}}
function tehranDayKey(d){try{return new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Tehran",year:"numeric",month:"2-digit",day:"2-digit"}).format(d)}catch{return d.toISOString().slice(0,10)}}
function toLocalDateTime(s){const d=new Date(s);if(Number.isNaN(d.getTime()))return"";const pad=n=>String(n).padStart(2,"0");return`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`}
function toast(msg){const el=$("#toast");el.textContent=msg;el.classList.add("show");clearTimeout(window.__toast);window.__toast=setTimeout(()=>el.classList.remove("show"),3200)}
function errorMessage(e){const map={invalid_password:"رمز اشتباه است.",password_too_short:"رمز باید حداقل ۱۰ کاراکتر باشد.",too_many_attempts:"تلاش‌های ورود زیاد است؛ کمی بعد دوباره امتحان کن.",ai_not_configured:"API هوش مصنوعی هنوز روی Worker تنظیم نشده.",ai_provider_error:"ارتباط با سرویس AI ناموفق بود.",ai_invalid_output:"پاسخ AI معتبر نبود.",unauthorized:"Session سرور معتبر نیست.",wrong_password:"رمز قفل آفلاین اشتباه است.",local_vault_missing:"Vault محلی این دستگاه ساخته نشده."};return map[e.message]||e.message||"خطایی رخ داد."}
