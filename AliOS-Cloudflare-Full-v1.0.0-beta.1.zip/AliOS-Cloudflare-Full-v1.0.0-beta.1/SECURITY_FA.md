# Security Notes

AliOS برای استفاده شخصی طراحی شده، اما امنیت نهایی فقط با Deploy و تست واقعی قابل ارزیابی است.

## انجام شده
- PBKDF2-SHA256 password hashing
- Server-side session cookies
- HttpOnly / SameSite Strict / Secure on HTTPS
- Basic brute-force protection
- AES-GCM encrypted IndexedDB vault
- CSP
- Soft delete
- Audit log
- Secret-based API key
- AI action validation
- No arbitrary SQL from AI
- Session revocation
- Automatic local lock

## قبل از داده‌های بسیار حساس
- WebAuthn/Passkey
- External security review
- D1 backup/restore drill
- File encryption
- Recovery strategy
- Multi-device conflict tests
- Monitoring and alerting
- Dependency review
