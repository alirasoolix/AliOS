# AliOS v1.0.0-beta.1 — Cloudflare Full Edition

این بسته نسخه‌ی **کامل‌تر و یکپارچه‌ی قابل اجرا** از AliOS است که بر پایه‌ی Cloudflare Workers ساخته شده است. هسته به صورت Offline-First، ماژولار، قابل شخصی‌سازی و مناسب PWA طراحی شده است.

> نکته مهم: «کامل» در این بسته یعنی هسته، ماژول‌ها، CRUD، آفلاین، Sync، امنیت، AI Gateway، ماژول‌ساز و بخش‌های اصلی زندگی همگی وجود دارند و قابل استفاده‌اند. با این حال قبل از ورود اطلاعات بسیار حساس و استفاده بلندمدت واقعی، تست Deployment، تست امنیت، Backup Recovery و تست چنددستگاهی روی محیط واقعی خودت لازم است. این نسخه را به‌عنوان **Feature-complete Beta** در نظر بگیر، نه محصولی که بدون تست عملی ادعای بی‌نقص بودن دارد.

## معماری

- Cloudflare Workers
- Cloudflare Static Assets
- Cloudflare D1
- PWA + Service Worker
- IndexedDB رمزگذاری‌شده با AES-GCM
- PBKDF2-SHA256 برای مشتق‌سازی کلید محلی
- Session Cookie امن سمت Worker
- Sync Queue آفلاین با Version Conflict Detection
- تقویم شمسی در UI
- منطقه زمانی `Asia/Tehran`
- رابط فارسی RTL
- AI Gateway اختیاری
- Structured Outputs برای تبدیل دستور طبیعی به Action کنترل‌شده
- Custom Module Builder

## ماژول‌های آماده

AliOS در این نسخه بیش از ۵۰ ماژول Built-in دارد:

Today، Inbox، Tasks، Calendar، Projects، Goals، Habits، Routines، Checklists، Notes، Ideas، Bookmarks، Journal، People، Events، Timeline، Finance، Accounts، Budgets، Bills، Subscriptions، Debts، Checks، Investments، Assets، Fitness، Workouts، Exercises، Body، Nutrition، Wellness، Sleep، Learning، Books، Courses، Skills، Travel، Places، Documents، Vehicle، Home، Shopping، Wishlist، Work، Business، Achievements، Challenges، Automations، Analytics، Global Search، Trash، Custom Modules، Settings و Ali AI.

هر ماژول داده‌های خودش را دارد اما هسته‌ی ذخیره‌سازی مشترک است؛ بنابراین بعداً می‌توان ماژول‌های جدید اضافه کرد بدون اینکه دیتای قبلی پاک شود.

---

# نصب

## 1. پیش‌نیاز

Node.js جدید روی لپ‌تاپ یا کامپیوتر.

در پوشه پروژه:

```bash
npm install
```

## 2. ورود به Cloudflare

```bash
npx wrangler login
```

## 3. ساخت D1

```bash
npm run db:create
```

این دستور از Wrangler می‌خواهد دیتابیس `alios-db` را بسازد، Binding با نام `DB` ایجاد کند و `wrangler.jsonc` را به‌روزرسانی کند.

اگر Wrangler از تو پرسید آیا Binding را به فایل Config اضافه کند، Yes را انتخاب کن.

## 4. ساخت جدول‌ها

```bash
npm run db:migrate:remote
```

## 5. AI اختیاری

برای OpenAI API Key:

```bash
npx wrangler secret put OPENAI_API_KEY
```

کلید را فقط در Terminal وارد کن. آن را در `app.js`، Git یا فایل عمومی قرار نده.

مدل پیش‌فرض:

```text
gpt-5.6-luna
```

در `wrangler.jsonc` قابل تغییر است.

استفاده از یک سرویس AI باید مطابق مناطق و شرایط استفاده رسمی همان سرویس باشد. Cloudflare Worker برای دورزدن محدودیت‌های ارائه‌دهنده AI طراحی نشده است.

## 6. Deploy

```bash
npm run deploy
```

در پایان Wrangler آدرس `workers.dev` را نشان می‌دهد.

برای اولین بار سایت را باز کن و رمز AliOS را بساز.

## 7. دامنه

Cloudflare Dashboard:

Workers & Pages → AliOS Worker → Settings / Domains & Routes → Custom Domain

دامنه یا ساب‌دامنه مثل:

```text
life.example.com
```

را متصل کن.

---

# آفلاین

بعد از اولین بارگذاری آنلاین:

- App Shell Cache می‌شود.
- اطلاعات محلی در IndexedDB ذخیره می‌شوند.
- داده‌های محلی با AES-GCM رمزگذاری می‌شوند.
- در حالت آفلاین می‌توانی رکورد بسازی، ویرایش کنی و حذف کنی.
- تغییرات در Outbox می‌مانند.
- با برگشت اینترنت Sync خودکار انجام می‌شود.
- AI در حالت آفلاین کار نمی‌کند.

برای تست واقعی:

1. سایت را آنلاین باز کن.
2. چند رکورد بساز.
3. PWA را نصب کن.
4. Airplane Mode را روشن کن.
5. برنامه را کامل ببند.
6. دوباره از Home Screen باز کن.
7. با رمز وارد شو.
8. داده‌ای اضافه کن.
9. اینترنت را وصل کن و Sync را بررسی کن.

---

# AI

Ali AI به دیتابیس SQL آزاد دسترسی ندارد.

جریان:

```text
User
  ↓
AI Gateway
  ↓
Structured Action Plan
  ↓
Validation
  ↓
Allowed Record Create/Update
  ↓
D1 + Local Sync
```

مثال:

```text
۴۵ هزار تومان لاستیک موتور
```

می‌تواند به یک رکورد Finance تبدیل شود.

یا:

```text
برنامه تمرین امروزمو بر اساس اطلاعات قبلیم بساز
```

می‌تواند Context مرتبط با Fitness/Workout را بخواند و رکورد Workout ایجاد کند.

حذف مستقیم رکورد توسط AI در این نسخه مجاز نیست.

---

# امنیت

موجود در نسخه فعلی:

- رمز Hash شده سمت Worker
- Rate Limit پایه برای تلاش ورود
- HttpOnly Session Cookie
- SameSite=Strict
- Secure Cookie در HTTPS
- CSP و Security Headers
- Session list و Revoke
- Change Password و Invalidating Sessions
- Local encrypted vault
- Auto Lock
- Soft Delete + Trash
- Audit Log سمت سرور
- API Key فقط Cloudflare Secret

قبل از ذخیره اطلاعات فوق‌حساس پیشنهاد می‌شود:
- تست امنیت Deployment واقعی
- تست بازیابی Backup
- Passkey/WebAuthn
- رمزگذاری End-to-End برای فایل‌های حساس
- سیاست نگهداری و Backup D1
- تست Sync روی چند دستگاه

---

# Backup

Settings → Backup / Export

خروجی JSON از داده‌های محلی می‌گیرد.

هشدار: فایل Export فعلی **رمزگذاری‌شده نیست**؛ آن را فقط در فضای امن نگه دار.

---

# ساخت ماژول سفارشی

از بخش «ماژول‌ساز» می‌توانی ماژول جدید بسازی.

مثال:

```text
نام: عطرها
شناسه: perfumes
فیلدها:
برند | text
قیمت | currency
امتیاز | number
تاریخ خرید | date
یادداشت | textarea
```

پس از ساخت، ماژول در منوی AliOS ظاهر می‌شود.

---

# فایل‌های مهم

```text
src/index.js              Worker API
public/index.html         UI Shell
public/app.js             Offline/Sync/UI Engine
public/modules.js         تعریف ماژول‌ها
public/app.css            Design System
public/sw.js              PWA Service Worker
schema.sql                D1 Schema
wrangler.jsonc            Cloudflare Config
README_FA.md              همین راهنما
FEATURES_FA.md            فهرست امکانات
SECURITY_FA.md            نکات امنیت
CHANGELOG.md              تغییرات نسخه
```

---

# وضعیت نسخه

این نسخه یک **Full Feature Beta** است.

مناسب:
- Deploy آزمایشی
- استفاده شخصی با داده غیرحساس تا پایان تست
- توسعه ماژول‌های جدید
- تست PWA/Offline/AI/Sync

قبل از استفاده به عنوان تنها محل نگهداری اطلاعات حساس یا حیاتی، Backup و Security Review واقعی لازم است.
