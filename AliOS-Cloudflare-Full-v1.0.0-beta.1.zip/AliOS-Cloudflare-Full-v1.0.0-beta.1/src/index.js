const SESSION_COOKIE = "alios_session";
const SESSION_SECONDS = 60 * 60 * 24 * 30;
const PASSWORD_ITERATIONS = 210000;
const JSON_HEADERS = {
  "content-type": "application/json; charset=utf-8",
  "cache-control": "no-store",
  "x-content-type-options": "nosniff",
  "referrer-policy": "no-referrer"
};

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (!url.pathname.startsWith("/api/")) {
      const response = await env.ASSETS.fetch(request);
      return secureAssetResponse(response);
    }

    try {
      if (request.method === "OPTIONS") return new Response(null, { status: 204 });

      if (url.pathname === "/api/health" && request.method === "GET") {
        return json({ ok: true, version: "1.0.0-beta.1", platform: "cloudflare-workers", time: new Date().toISOString() });
      }

      if (url.pathname === "/api/bootstrap" && request.method === "GET") {
        const owner = await env.DB.prepare("SELECT COUNT(*) AS c FROM users").first();
        return json({
          ok: true,
          configured: Number(owner?.c || 0) > 0,
          app: env.APP_NAME || "AliOS",
          timezone: env.TIME_ZONE || "Asia/Tehran",
          aiConfigured: Boolean(env.OPENAI_API_KEY),
          aiProvider: env.AI_PROVIDER || "openai",
          version: "1.0.0-beta.1"
        });
      }

      if (url.pathname === "/api/setup" && request.method === "POST") {
        assertMutation(request);
        return handleSetup(request, env);
      }

      if (url.pathname === "/api/auth/login" && request.method === "POST") {
        assertMutation(request);
        return handleLogin(request, env);
      }

      if (url.pathname === "/api/auth/logout" && request.method === "POST") {
        assertMutation(request);
        const token = getCookie(request, SESSION_COOKIE);
        if (token) await env.DB.prepare("DELETE FROM sessions WHERE token_hash = ?").bind(await sha256(token)).run();
        return json({ ok: true }, 200, {
          "set-cookie": cookieHeader("", 0, new URL(request.url).protocol === "https:")
        });
      }

      const user = await requireUser(request, env);

      if (url.pathname === "/api/me" && request.method === "GET") {
        return json({ ok: true, user });
      }

      if (url.pathname === "/api/auth/change-password" && request.method === "POST") {
        assertMutation(request);
        return handleChangePassword(request, env, user);
      }

      if (url.pathname === "/api/auth/sessions" && request.method === "GET") {
        const result = await env.DB.prepare(`
          SELECT id, user_agent, ip_hint, created_at, last_seen_at, expires_at
          FROM sessions WHERE user_id = ? ORDER BY last_seen_at DESC
        `).bind(user.id).all();
        return json({ ok: true, sessions: result.results || [] });
      }

      const sessionMatch = url.pathname.match(/^\/api\/auth\/sessions\/([a-zA-Z0-9_-]+)$/);
      if (sessionMatch && request.method === "DELETE") {
        assertMutation(request);
        await env.DB.prepare("DELETE FROM sessions WHERE id = ? AND user_id = ?").bind(sessionMatch[1], user.id).run();
        await audit(env, user.id, "session_revoked", null, null, { session_id: sessionMatch[1] });
        return json({ ok: true });
      }

      if (url.pathname === "/api/auth/logout-all" && request.method === "POST") {
        assertMutation(request);
        await env.DB.prepare("DELETE FROM sessions WHERE user_id = ?").bind(user.id).run();
        await audit(env, user.id, "all_sessions_revoked", null, null, {});
        return json({ ok: true }, 200, {
          "set-cookie": cookieHeader("", 0, new URL(request.url).protocol === "https:")
        });
      }

      if (url.pathname === "/api/settings" && request.method === "GET") {
        const result = await env.DB.prepare("SELECT key, value, updated_at FROM settings WHERE user_id = ?").bind(user.id).all();
        const settings = {};
        for (const row of result.results || []) settings[row.key] = safeJson(row.value);
        return json({ ok: true, settings });
      }

      if (url.pathname === "/api/settings" && request.method === "PUT") {
        assertMutation(request);
        const body = await readJson(request);
        const entries = body.settings && typeof body.settings === "object" ? Object.entries(body.settings) : [];
        const now = new Date().toISOString();
        for (const [key, value] of entries.slice(0, 100)) {
          if (!/^[a-zA-Z0-9_.-]{1,80}$/.test(key)) continue;
          await env.DB.prepare(`
            INSERT INTO settings (user_id, key, value, updated_at) VALUES (?, ?, ?, ?)
            ON CONFLICT(user_id, key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at
          `).bind(user.id, key, JSON.stringify(value ?? null), now).run();
        }
        return json({ ok: true });
      }

      if (url.pathname === "/api/records" && request.method === "GET") {
        return listRecords(request, env, user);
      }

      if (url.pathname === "/api/records" && request.method === "POST") {
        assertMutation(request);
        return createRecord(request, env, user);
      }

      const recordMatch = url.pathname.match(/^\/api\/records\/([a-zA-Z0-9_-]+)$/);
      if (recordMatch && request.method === "GET") {
        const rec = await getRecord(env, user.id, recordMatch[1]);
        if (!rec) throw httpError(404, "record_not_found");
        return json({ ok: true, record: rec });
      }
      if (recordMatch && request.method === "PATCH") {
        assertMutation(request);
        return updateRecord(request, env, user, recordMatch[1]);
      }
      if (recordMatch && request.method === "DELETE") {
        assertMutation(request);
        return softDeleteRecord(env, user, recordMatch[1]);
      }

      const restoreMatch = url.pathname.match(/^\/api\/records\/([a-zA-Z0-9_-]+)\/restore$/);
      if (restoreMatch && request.method === "POST") {
        assertMutation(request);
        const current = await getRecord(env, user.id, restoreMatch[1]);
        if (!current) throw httpError(404, "record_not_found");
        const now = new Date().toISOString();
        await env.DB.prepare(`
          UPDATE records SET deleted_at = NULL, updated_at = ?, version = version + 1
          WHERE id = ? AND user_id = ?
        `).bind(now, restoreMatch[1], user.id).run();
        await audit(env, user.id, "record_restored", restoreMatch[1], current.module, {});
        return json({ ok: true, record: await getRecord(env, user.id, restoreMatch[1]) });
      }

      if (url.pathname === "/api/sync" && request.method === "POST") {
        assertMutation(request);
        return syncRecords(request, env, user);
      }

      if (url.pathname === "/api/export" && request.method === "GET") {
        const recordsRes = await env.DB.prepare("SELECT * FROM records WHERE user_id = ? ORDER BY updated_at").bind(user.id).all();
        const settingsRes = await env.DB.prepare("SELECT key, value, updated_at FROM settings WHERE user_id = ?").bind(user.id).all();
        return json({
          ok: true,
          exported_at: new Date().toISOString(),
          version: "1.0.0-beta.1",
          records: (recordsRes.results || []).map(normalizeRecord),
          settings: (settingsRes.results || []).map(r => ({ ...r, value: safeJson(r.value) }))
        });
      }

      if (url.pathname === "/api/audit" && request.method === "GET") {
        const result = await env.DB.prepare(`
          SELECT id, action, record_id, module, meta, created_at
          FROM audit_logs WHERE user_id = ? ORDER BY created_at DESC LIMIT 300
        `).bind(user.id).all();
        return json({ ok: true, logs: (result.results || []).map(r => ({ ...r, meta: safeJson(r.meta) })) });
      }

      if (url.pathname === "/api/ai" && request.method === "POST") {
        assertMutation(request);
        return handleAI(request, env, user);
      }

      return json({ ok: false, error: "not_found" }, 404);
    } catch (error) {
      const status = Number(error?.status || 500);
      const message = status >= 500 ? "server_error" : String(error?.message || "request_failed");
      if (status >= 500) console.error(error);
      return json({ ok: false, error: message }, status);
    }
  }
};

function secureAssetResponse(response) {
  const h = new Headers(response.headers);
  h.set("x-content-type-options", "nosniff");
  h.set("referrer-policy", "strict-origin-when-cross-origin");
  h.set("permissions-policy", "camera=(), geolocation=(), payment=()");
  h.set("content-security-policy",
    "default-src 'self'; " +
    "script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
    "font-src 'self' https://fonts.gstatic.com data:; img-src 'self' data: blob:; " +
    "connect-src 'self' https://api.openai.com; object-src 'none'; base-uri 'self'; frame-ancestors 'none'"
  );
  return new Response(response.body, { status: response.status, statusText: response.statusText, headers: h });
}

async function handleSetup(request, env) {
  const row = await env.DB.prepare("SELECT COUNT(*) AS c FROM users").first();
  if (Number(row?.c || 0) > 0) throw httpError(409, "already_configured");

  const body = await readJson(request);
  const password = String(body.password || "");
  validatePassword(password);

  const salt = randomB64(18);
  const hash = await pbkdf2(password, salt, PASSWORD_ITERATIONS);
  const id = crypto.randomUUID();
  const now = new Date().toISOString();

  await env.DB.prepare(`
    INSERT INTO users (id, username, password_hash, password_salt, password_iterations, created_at, updated_at)
    VALUES (?, 'owner', ?, ?, ?, ?, ?)
  `).bind(id, hash, salt, PASSWORD_ITERATIONS, now, now).run();

  const defaults = {
    "profile": { displayName: "علی", timezone: "Asia/Tehran", calendar: "jalali", currency: "IRT" },
    "ui": { theme: "dark", accent: "#6d7cff", density: "comfortable" },
    "security": { autoLockMinutes: 15 },
    "home": { widgets: ["tasks","finance","workouts","nutrition","goals","habits","investments","notes"] }
  };
  for (const [key, value] of Object.entries(defaults)) {
    await env.DB.prepare("INSERT INTO settings (user_id,key,value,updated_at) VALUES (?,?,?,?)")
      .bind(id, key, JSON.stringify(value), now).run();
  }

  await audit(env, id, "setup_completed", null, null, {});
  return issueSession(request, env, { id, username: "owner" });
}

async function handleLogin(request, env) {
  const body = await readJson(request);
  const password = String(body.password || "");
  const ip = request.headers.get("CF-Connecting-IP") || "unknown";
  const ipHash = await sha256(ip);
  const cutoff = new Date(Date.now() - 15 * 60 * 1000).toISOString();

  await env.DB.prepare("DELETE FROM auth_attempts WHERE created_at < ?").bind(cutoff).run();
  const failed = await env.DB.prepare(
    "SELECT COUNT(*) AS c FROM auth_attempts WHERE ip_hash = ? AND ok = 0 AND created_at >= ?"
  ).bind(ipHash, cutoff).first();
  if (Number(failed?.c || 0) >= 5) throw httpError(429, "too_many_attempts");

  const owner = await env.DB.prepare(
    "SELECT id, username, password_hash, password_salt, password_iterations FROM users LIMIT 1"
  ).first();
  if (!owner) throw httpError(409, "not_configured");

  const candidate = await pbkdf2(password, owner.password_salt, Number(owner.password_iterations));
  const ok = safeEqual(candidate, owner.password_hash);

  await env.DB.prepare(
    "INSERT INTO auth_attempts (id, ip_hash, ok, created_at) VALUES (?, ?, ?, ?)"
  ).bind(crypto.randomUUID(), ipHash, ok ? 1 : 0, new Date().toISOString()).run();

  if (!ok) throw httpError(401, "invalid_password");
  return issueSession(request, env, { id: owner.id, username: owner.username });
}

async function issueSession(request, env, user) {
  const token = randomB64(32);
  const tokenHash = await sha256(token);
  const now = new Date();
  const expires = new Date(now.getTime() + SESSION_SECONDS * 1000);
  const ip = request.headers.get("CF-Connecting-IP") || "";

  await env.DB.prepare(`
    INSERT INTO sessions (id, token_hash, user_id, user_agent, ip_hint, created_at, last_seen_at, expires_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    crypto.randomUUID(), tokenHash, user.id,
    (request.headers.get("user-agent") || "").slice(0, 300),
    ip ? ip.replace(/\d+$/, "x").slice(0,80) : "",
    now.toISOString(), now.toISOString(), expires.toISOString()
  ).run();

  return json({ ok: true, user }, 200, {
    "set-cookie": cookieHeader(token, SESSION_SECONDS, new URL(request.url).protocol === "https:")
  });
}

async function requireUser(request, env) {
  const token = getCookie(request, SESSION_COOKIE);
  if (!token) throw httpError(401, "unauthorized");
  const hash = await sha256(token);
  const now = new Date().toISOString();

  const row = await env.DB.prepare(`
    SELECT u.id, u.username, s.id AS session_id
    FROM sessions s JOIN users u ON u.id = s.user_id
    WHERE s.token_hash = ? AND s.expires_at > ?
    LIMIT 1
  `).bind(hash, now).first();

  if (!row) throw httpError(401, "unauthorized");
  await env.DB.prepare("UPDATE sessions SET last_seen_at = ? WHERE id = ?").bind(now, row.session_id).run();
  return { id: row.id, username: row.username, session_id: row.session_id };
}

async function handleChangePassword(request, env, user) {
  const body = await readJson(request);
  const currentPassword = String(body.currentPassword || "");
  const newPassword = String(body.newPassword || "");
  validatePassword(newPassword);

  const row = await env.DB.prepare(
    "SELECT password_hash, password_salt, password_iterations FROM users WHERE id = ?"
  ).bind(user.id).first();
  const candidate = await pbkdf2(currentPassword, row.password_salt, Number(row.password_iterations));
  if (!safeEqual(candidate, row.password_hash)) throw httpError(401, "invalid_password");

  const salt = randomB64(18);
  const hash = await pbkdf2(newPassword, salt, PASSWORD_ITERATIONS);
  const now = new Date().toISOString();
  await env.DB.prepare(`
    UPDATE users SET password_hash = ?, password_salt = ?, password_iterations = ?, updated_at = ?
    WHERE id = ?
  `).bind(hash, salt, PASSWORD_ITERATIONS, now, user.id).run();

  await env.DB.prepare("DELETE FROM sessions WHERE user_id = ?").bind(user.id).run();
  await audit(env, user.id, "password_changed", null, null, {});
  return json({ ok: true }, 200, {
    "set-cookie": cookieHeader("", 0, new URL(request.url).protocol === "https:")
  });
}

async function listRecords(request, env, user) {
  const url = new URL(request.url);
  const since = url.searchParams.get("since");
  const module = url.searchParams.get("module");
  const includeDeleted = url.searchParams.get("include_deleted") === "1";
  const q = (url.searchParams.get("q") || "").trim().slice(0,100);

  const clauses = ["user_id = ?"];
  const params = [user.id];
  if (since) { clauses.push("updated_at > ?"); params.push(since); }
  if (module) { clauses.push("module = ?"); params.push(module); }
  if (!includeDeleted) clauses.push("deleted_at IS NULL");
  if (q) { clauses.push("(title LIKE ? OR payload LIKE ?)"); params.push(`%${q}%`, `%${q}%`); }

  const sql = `SELECT * FROM records WHERE ${clauses.join(" AND ")} ORDER BY updated_at DESC LIMIT 3000`;
  const result = await env.DB.prepare(sql).bind(...params).all();
  return json({ ok: true, records: (result.results || []).map(normalizeRecord), server_time: new Date().toISOString() });
}

async function createRecord(request, env, user) {
  const body = await readJson(request);
  const record = sanitizeRecordInput(body);
  const now = new Date().toISOString();
  const id = validId(String(body.id || "")) ? String(body.id) : crypto.randomUUID();

  await env.DB.prepare(`
    INSERT INTO records (id, user_id, module, title, payload, occurred_at, created_at, updated_at, version, device_id)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
  `).bind(
    id, user.id, record.module, record.title, JSON.stringify(record.payload),
    record.occurred_at || now, now, now, String(body.device_id || "")
  ).run();

  await audit(env, user.id, "record_created", id, record.module, {});
  return json({ ok: true, record: await getRecord(env, user.id, id) }, 201);
}

async function updateRecord(request, env, user, id) {
  const body = await readJson(request);
  const current = await getRecord(env, user.id, id);
  if (!current || current.deleted_at) throw httpError(404, "record_not_found");

  if (body.base_version != null && Number(body.base_version) !== Number(current.version)) {
    return json({ ok: false, error: "version_conflict", record: current }, 409);
  }

  const next = sanitizeRecordInput({
    module: body.module ?? current.module,
    title: body.title ?? current.title,
    payload: body.payload ?? current.payload,
    occurred_at: body.occurred_at ?? current.occurred_at
  });
  const now = new Date().toISOString();

  await env.DB.prepare(`
    UPDATE records
    SET module = ?, title = ?, payload = ?, occurred_at = ?, updated_at = ?, version = version + 1
    WHERE id = ? AND user_id = ?
  `).bind(
    next.module, next.title, JSON.stringify(next.payload), next.occurred_at || now, now, id, user.id
  ).run();

  await audit(env, user.id, "record_updated", id, next.module, {});
  return json({ ok: true, record: await getRecord(env, user.id, id) });
}

async function softDeleteRecord(env, user, id) {
  const current = await getRecord(env, user.id, id);
  if (!current) throw httpError(404, "record_not_found");
  const now = new Date().toISOString();
  await env.DB.prepare(`
    UPDATE records SET deleted_at = ?, updated_at = ?, version = version + 1
    WHERE id = ? AND user_id = ?
  `).bind(now, now, id, user.id).run();
  await audit(env, user.id, "record_deleted", id, current.module, {});
  return json({ ok: true, record: await getRecord(env, user.id, id) });
}

async function syncRecords(request, env, user) {
  const body = await readJson(request);
  const ops = Array.isArray(body.ops) ? body.ops.slice(0, 300) : [];
  const applied = [];
  const conflicts = [];

  for (const op of ops) {
    const opId = String(op?.op_id || crypto.randomUUID());
    const id = String(op?.record?.id || op?.id || "");
    if (!validId(id)) continue;

    const current = await getRecord(env, user.id, id);
    const baseVersion = Number(op.base_version || 0);

    if (current && baseVersion && Number(current.version) !== baseVersion) {
      conflicts.push({ op_id: opId, id, local: op.record || null, server: current });
      continue;
    }

    try {
      if (op.kind === "delete") {
        if (current) await softDeleteRecord(env, user, id);
      } else if (op.kind === "restore") {
        if (current) {
          const now = new Date().toISOString();
          await env.DB.prepare(`
            UPDATE records SET deleted_at = NULL, updated_at = ?, version = version + 1
            WHERE id = ? AND user_id = ?
          `).bind(now, id, user.id).run();
        }
      } else if (op.kind === "upsert") {
        const clean = sanitizeRecordInput(op.record || {});
        const now = new Date().toISOString();
        if (!current) {
          await env.DB.prepare(`
            INSERT INTO records (id, user_id, module, title, payload, occurred_at, created_at, updated_at, version, device_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
          `).bind(
            id, user.id, clean.module, clean.title, JSON.stringify(clean.payload),
            clean.occurred_at || now, now, now, String(op.record?.device_id || "")
          ).run();
        } else {
          await env.DB.prepare(`
            UPDATE records
            SET module=?, title=?, payload=?, occurred_at=?, updated_at=?, deleted_at=?, version=version+1, device_id=?
            WHERE id=? AND user_id=?
          `).bind(
            clean.module, clean.title, JSON.stringify(clean.payload),
            clean.occurred_at || current.occurred_at || now,
            now, op.record?.deleted_at || null, String(op.record?.device_id || ""),
            id, user.id
          ).run();
        }
      } else {
        continue;
      }
      applied.push({ op_id: opId, record: await getRecord(env, user.id, id) });
    } catch (e) {
      console.error("sync_op_failed", e);
    }
  }

  return json({ ok: true, applied, conflicts, server_time: new Date().toISOString() });
}

async function handleAI(request, env, user) {
  if (!env.OPENAI_API_KEY) throw httpError(503, "ai_not_configured");
  if ((env.AI_PROVIDER || "openai") !== "openai") throw httpError(503, "ai_provider_not_implemented");

  const body = await readJson(request);
  const message = String(body.message || "").trim().slice(0, 5000);
  if (!message) throw httpError(400, "message_required");

  const relevantModules = inferContextModules(message);
  const params = [user.id];
  let moduleClause = "";
  if (relevantModules.length) {
    moduleClause = ` AND module IN (${relevantModules.map(() => "?").join(",")})`;
    params.push(...relevantModules);
  }
  const result = await env.DB.prepare(`
    SELECT id, module, title, payload, occurred_at, updated_at, version
    FROM records
    WHERE user_id = ? AND deleted_at IS NULL ${moduleClause}
    ORDER BY updated_at DESC LIMIT 80
  `).bind(...params).all();

  const context = (result.results || []).map(r => ({
    id: r.id,
    module: r.module,
    title: r.title,
    payload: safeJson(r.payload),
    occurred_at: r.occurred_at,
    version: r.version
  }));

  const tehran = new Intl.DateTimeFormat("fa-IR-u-ca-persian", {
    timeZone: env.TIME_ZONE || "Asia/Tehran",
    weekday: "long", year: "numeric", month: "long", day: "numeric",
    hour: "2-digit", minute: "2-digit"
  }).format(new Date());

  const schema = {
    type: "object",
    properties: {
      reply: { type: "string" },
      needs_clarification: { type: "boolean" },
      clarifying_question: { type: "string" },
      actions: {
        type: "array",
        items: {
          type: "object",
          properties: {
            action: { type: "string", enum: ["create_record", "update_record"] },
            module: { type: "string" },
            record_id: { type: "string" },
            title: { type: "string" },
            occurred_at: { type: "string" },
            data_json: { type: "string" },
            requires_confirmation: { type: "boolean" }
          },
          required: ["action","module","record_id","title","occurred_at","data_json","requires_confirmation"],
          additionalProperties: false
        }
      }
    },
    required: ["reply","needs_clarification","clarifying_question","actions"],
    additionalProperties: false
  };

  const instructions =
    "تو مغز شخصی AliOS هستی. پاسخ‌ها فارسی، کوتاه و دقیق باشند. " +
    "هدف اصلی: درخواست کاربر را بفهم، فقط داده مرتبط را استفاده کن و در صورت امکان Action ساختاریافته ایجاد کن. " +
    "ماژول‌های متداول: tasks, calendar, projects, goals, habits, notes, journal, finance, accounts, budgets, bills, investments, assets, workouts, fitness, nutrition, wellness, sleep, learning, people, travel, vehicle, home, shopping, wishlist. " +
    "برای ثبت هزینه module=finance و payload شامل transaction_type='expense', amount, currency='IRT', category و جزئیات باشد. " +
    "برای تمرین module=workouts و payload شامل focus,duration,exercises,status='planned' باشد. " +
    "اگر اطلاعات حیاتی کم است فقط یک سؤال کوتاه و ضروری بپرس. سؤال اضافی نپرس. " +
    "هیچ Action حذف تولید نکن. برای تغییر حساس requires_confirmation=true بگذار. " +
    "data_json باید یک JSON object معتبر به صورت رشته باشد. هیچ SQL یا کد آزاد تولید نکن.";

  const aiRes = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "authorization": `Bearer ${env.OPENAI_API_KEY}`,
      "content-type": "application/json"
    },
    body: JSON.stringify({
      model: env.AI_MODEL || "gpt-5.6-luna",
      store: false,
      max_output_tokens: 1800,
      instructions,
      input: `زمان فعلی تهران/شمسی: ${tehran}\n\nدرخواست کاربر:\n${message}\n\nداده مرتبط AliOS:\n${JSON.stringify(context).slice(0,26000)}`,
      text: {
        format: {
          type: "json_schema",
          name: "alios_action_plan",
          strict: true,
          schema
        }
      }
    })
  });

  const raw = await aiRes.json();
  if (!aiRes.ok) {
    console.error("openai_error", raw);
    throw httpError(502, "ai_provider_error");
  }

  const output = extractOutputText(raw);
  let plan;
  try { plan = JSON.parse(output); }
  catch { throw httpError(502, "ai_invalid_output"); }

  const appliedRecords = [];
  const pendingActions = [];
  if (!plan.needs_clarification) {
    for (const action of (plan.actions || []).slice(0, 12)) {
      if (action.requires_confirmation) {
        pendingActions.push(action);
        continue;
      }
      const saved = await executeAIAction(env, user, action);
      if (saved) appliedRecords.push(saved);
    }
  }

  await env.DB.prepare(`
    INSERT INTO ai_logs (id,user_id,prompt_preview,result_preview,actions_count,created_at)
    VALUES (?,?,?,?,?,?)
  `).bind(
    crypto.randomUUID(), user.id, message.slice(0,240), String(plan.reply || "").slice(0,500),
    appliedRecords.length, new Date().toISOString()
  ).run();

  return json({
    ok: true,
    reply: String(plan.reply || ""),
    needs_clarification: Boolean(plan.needs_clarification),
    clarifying_question: String(plan.clarifying_question || ""),
    records: appliedRecords,
    pending_actions: pendingActions
  });
}

async function executeAIAction(env, user, action) {
  const module = String(action.module || "").toLowerCase();
  if (!validModule(module)) return null;

  let data = {};
  try { data = JSON.parse(String(action.data_json || "{}")); }
  catch { data = {}; }
  if (!data || typeof data !== "object" || Array.isArray(data)) data = {};

  const now = new Date().toISOString();
  const occurred = validDateString(action.occurred_at) ? String(action.occurred_at) : now;

  if (action.action === "create_record") {
    const id = crypto.randomUUID();
    await env.DB.prepare(`
      INSERT INTO records (id,user_id,module,title,payload,occurred_at,created_at,updated_at,version,device_id)
      VALUES (?,?,?,?,?,?,?,?,1,'ai')
    `).bind(id,user.id,module,String(action.title||module).slice(0,240),JSON.stringify({ ...data, source:"ai" }),occurred,now,now).run();
    await audit(env,user.id,"ai_record_created",id,module,{});
    return getRecord(env,user.id,id);
  }

  if (action.action === "update_record" && validId(String(action.record_id || ""))) {
    const current = await getRecord(env,user.id,String(action.record_id));
    if (!current) return null;
    await env.DB.prepare(`
      UPDATE records SET module=?, title=?, payload=?, occurred_at=?, updated_at=?, version=version+1
      WHERE id=? AND user_id=?
    `).bind(
      module,
      String(action.title || current.title).slice(0,240),
      JSON.stringify({ ...current.payload, ...data, source:"ai" }),
      occurred || current.occurred_at,
      now,current.id,user.id
    ).run();
    await audit(env,user.id,"ai_record_updated",current.id,module,{});
    return getRecord(env,user.id,current.id);
  }
  return null;
}

function inferContextModules(message) {
  const m = message.toLowerCase();
  if (/تمرین|ورزش|باشگاه|جیم|وزنه|فیتنس|بدن/.test(m)) return ["workouts","fitness","body","wellness","goals","nutrition","sleep"];
  if (/غذا|تغذیه|کالری|پروتئین|ناهار|صبحانه|شام/.test(m)) return ["nutrition","workouts","fitness","body","wellness"];
  if (/خرج|هزینه|پول|تومان|تومن|مالی|خرید|قسط|درآمد|بدهی|سرمایه|دلار|طلا|ارز|رمز/.test(m))
    return ["finance","accounts","budgets","bills","subscriptions","debts","checks","investments","assets","vehicle"];
  if (/کار|تسک|وظیفه|برنامه امروز|فردا|قرار|تقویم|یادآوری/.test(m)) return ["tasks","calendar","projects","goals","habits","routines"];
  if (/یادداشت|نوت|ایده|ژورنال/.test(m)) return ["notes","ideas","journal"];
  if (/ماشین|خودرو|موتور|بنزین|لاستیک|روغن|سرویس/.test(m)) return ["vehicle","finance","bills"];
  return [];
}

function sanitizeRecordInput(body) {
  const module = String(body.module || "").toLowerCase();
  if (!validModule(module)) throw httpError(400, "invalid_module");
  const title = String(body.title || "").slice(0, 240);
  const payload = body.payload && typeof body.payload === "object" && !Array.isArray(body.payload) ? body.payload : {};
  const occurred_at = validDateString(body.occurred_at) ? String(body.occurred_at) : null;
  return { module, title, payload, occurred_at };
}

async function getRecord(env, userId, id) {
  const row = await env.DB.prepare("SELECT * FROM records WHERE id=? AND user_id=? LIMIT 1").bind(id,userId).first();
  return row ? normalizeRecord(row) : null;
}

function normalizeRecord(row) {
  return { ...row, payload: safeJson(row.payload) };
}

function safeJson(value) {
  if (typeof value !== "string") return value ?? {};
  try { return JSON.parse(value); } catch { return {}; }
}

async function audit(env,userId,action,recordId,module,meta) {
  await env.DB.prepare(`
    INSERT INTO audit_logs (id,user_id,action,record_id,module,meta,created_at)
    VALUES (?,?,?,?,?,?,?)
  `).bind(crypto.randomUUID(),userId,action,recordId,module,JSON.stringify(meta||{}),new Date().toISOString()).run();
}

function extractOutputText(data) {
  if (typeof data?.output_text === "string") return data.output_text;
  for (const item of data?.output || []) {
    for (const c of item?.content || []) {
      if (c?.type === "output_text" && typeof c.text === "string") return c.text;
      if (typeof c?.text === "string") return c.text;
    }
  }
  return "";
}

async function readJson(request) {
  const ct = request.headers.get("content-type") || "";
  if (!ct.includes("application/json")) throw httpError(415,"json_required");
  try { return await request.json(); }
  catch { throw httpError(400,"invalid_json"); }
}

function assertMutation(request) {
  if (request.headers.get("x-alios-action") !== "1") throw httpError(403,"action_header_required");
  const origin = request.headers.get("origin");
  if (origin) {
    const req = new URL(request.url);
    const org = new URL(origin);
    if (req.host !== org.host || req.protocol !== org.protocol) throw httpError(403,"origin_mismatch");
  }
}

function validatePassword(password) {
  if (password.length < 10) throw httpError(400,"password_too_short");
  if (password.length > 200) throw httpError(400,"password_too_long");
}

function getCookie(request,name) {
  const raw = request.headers.get("cookie") || "";
  for (const part of raw.split(";")) {
    const [k,...rest] = part.trim().split("=");
    if (k === name) return decodeURIComponent(rest.join("="));
  }
  return null;
}

function cookieHeader(token,maxAge,secure) {
  return `${SESSION_COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAge}${secure?"; Secure":""}`;
}

async function pbkdf2(password,saltB64,iterations) {
  const key = await crypto.subtle.importKey("raw",new TextEncoder().encode(password),"PBKDF2",false,["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({name:"PBKDF2",hash:"SHA-256",salt:b64ToBytes(saltB64),iterations},key,256);
  return bytesToB64(new Uint8Array(bits));
}

async function sha256(value) {
  const digest = await crypto.subtle.digest("SHA-256",new TextEncoder().encode(value));
  return bytesToB64(new Uint8Array(digest));
}

function randomB64(n) {
  const a = new Uint8Array(n); crypto.getRandomValues(a); return bytesToB64(a);
}
function bytesToB64(bytes) {
  let s=""; for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");
}
function b64ToBytes(s) {
  s=s.replace(/-/g,"+").replace(/_/g,"/"); while(s.length%4)s+="=";
  const raw=atob(s); return Uint8Array.from(raw,c=>c.charCodeAt(0));
}
function safeEqual(a,b) {
  if (a.length!==b.length) return false;
  let x=0; for(let i=0;i<a.length;i++)x|=a.charCodeAt(i)^b.charCodeAt(i); return x===0;
}
function validId(s){ return /^[a-zA-Z0-9_-]{8,80}$/.test(s); }
function validModule(s){ return /^[a-z][a-z0-9_-]{0,50}$/.test(s); }
function validDateString(s){ return typeof s==="string" && s.length<80 && !Number.isNaN(Date.parse(s)); }

function json(data,status=200,extra={}) {
  return new Response(JSON.stringify(data),{status,headers:{...JSON_HEADERS,...extra}});
}
function httpError(status,message){const e=new Error(message);e.status=status;return e;}
