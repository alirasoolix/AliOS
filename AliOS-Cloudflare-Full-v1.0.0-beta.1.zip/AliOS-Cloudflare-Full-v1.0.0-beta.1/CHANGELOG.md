# Changelog

## 1.0.0-beta.1
- مهاجرت کامل معماری به Cloudflare Workers + D1
- 50+ ماژول Built-in
- Dynamic Module Engine
- Custom Module Builder
- Offline encrypted vault
- PWA + Service Worker
- Offline CRUD
- Sync Queue + version conflict detection
- Persian/Jalali UI and Tehran time
- Global Search
- Analytics
- Trash and Restore
- Backup Export/Import
- Theme customization
- Auto Lock
- Session management
- Ali AI Gateway
- AI create/update records with structured output
- Finance/Fitness/Nutrition/Goals/Vehicle specialized fields
- Mobile and desktop responsive layouts
